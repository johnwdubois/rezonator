cd "${0%/*}"
g++ -c -std=c++17 "FileManager.cpp" -fPIC -m64
g++ "FileManager.o" -o "FileManager (x64)/FileManager.so" -shared -fPIC -m64
