cd "${0%/*}"
g++ -c -std=c++17 "FileManager.cpp" -fPIC -m32
g++ "FileManager.o" -o "FileManager (x86)/FileManager.dylib" -shared -fPIC -m32
