/******************************************************************************

 MIT License

 Copyright © 2019 Samuel Venable

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.

******************************************************************************/

#include "FileManager.h"
#include <fts.h>
#include <string>
#include <fstream>
#include <iostream>
#include <algorithm>
#include <cstdlib>
#include <climits>
#include <cstring>
#include <dirent.h>
#include <libgen.h>
#include <unistd.h>
#include <sys/stat.h>
#include <mach-o/dyld.h>
using namespace std;

struct dupslash {
  bool operator()(char a, char b) const {
    return (a == '/' && b == '/');
  }
};

static string string_replace_all(string str, string substr, string newstr) {
  size_t pos = 0;
  const size_t sublen = substr.length(), newlen = newstr.length();
  
  while ((pos = str.find(substr, pos)) != string::npos) {
    str.replace(pos, sublen, newstr);
    pos += newlen;
  }
  
  return str;
}

static string filename_name(string fname) {
  size_t fp = fname.find_last_of("/");
  return fname.substr(fp+1);
}

static string filename_path(string fname) {
  size_t fp = fname.find_last_of("/");
  return fname.substr(0,fp+1);
}

static string filename_dir(string fname) {
  size_t fp = fname.find_last_of("/");
  if (fp == string::npos)
    return "";
  return fname.substr(0, fp);
}

static string filename_ext(string fname) {
  fname = filename_name(fname);
  size_t fp = fname.find_last_of(".");
  if (fp == string::npos)
    return "";
  return fname.substr(fp);
}

static bool generate_working_directory() {
  /*
    This function will set the working directory to the app bundle's "Resources" folder
    If the executable is not in an app bundle, then do not change the working directory

    ONLY use working_directory for loading read-only included files! When SAVING, use game_save_id

    *_bname = base name - removes the full path from the string leaving just the file or folder name
    *_dname = directory name - removes final slash and base name from full path to file or folder name
    *_pname = path name - removes the base name from a full path while keeping the dir and final slash
    *_ename = extension name - includes everything in bname at and following the period if one exists
  */

  bool success = false;
  string exe_pname = get_program_directory();             // = "/Path/To/YourAppBundle.app/Contents/MacOS/";
  string macos_dname = filename_dir(exe_pname);           // = "/Path/To/YourAppBundle.app/Contents/MacOS";
  string macos_bname = filename_name(macos_dname);        // = "MacOS";
  string contents_dname = filename_dir(macos_dname);      // = "/Path/To/YourAppBundle.app/Contents";
  string contents_bname = filename_name(contents_dname);  // = "Contents";
  string app_dname = filename_dir(contents_dname);        // = "/Path/To/YourAppBundle.app";
  string app_ename = filename_ext(app_dname);             // = ".app";
  string contents_pname = filename_path(macos_dname);     // = "/Path/To/YourAppBundle.app/Contents/";
  string resources_pname = contents_pname + "Resources/"; // = "/Path/To/YourAppBundle.app/Contents/Resources/";

  // if "/Path/To/YourAppBundle.app/Contents/MacOS/YourExe" and "/Path/To/YourAppBundle.app/Contents/Resources/" exists
  if (macos_bname == "MacOS" && contents_bname == "Contents" && app_ename == ".app" && directory_exists((char *)resources_pname.c_str())) {
    // set working directory to "/Path/To/YourAppBundle.app/Contents/Resources/" and allow loading normal included files
    success = set_working_directory((char *)resources_pname.c_str());
  }

  return success;
}

double file_copy(char *fname, char *newname) {
  string str1(fname);
  string str2(newname);
  
  str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
  str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());
  
  int proceed = 0;
  
  string prestr1 = str1;
  string prestr2 = str2;
  
  char *cstr1 = (char *)str1.c_str();
  char *cstr2;
  
  string pardir1(dirname(cstr1));
  if (!pardir1.empty()) {
    while (*pardir1.rbegin() == '/') {
      pardir1.erase(pardir1.size() - 1);
    }
  }
  struct stat pexist1;
  if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
    S_ISDIR(pexist1.st_mode)) {
    char actpath1[PATH_MAX];
    char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
    if (ptr1 != NULL) {
      cstr2 = (char *)str2.c_str();
      string pardir2(dirname(cstr2));
      if (!pardir2.empty()) {
        while (*pardir2.rbegin() == '/') {
          pardir2.erase(pardir2.size() - 1);
        }
      }
      struct stat pexist2;
      if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
        S_ISDIR(pexist2.st_mode)) {
        char actpath2[PATH_MAX];
        char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
        if (ptr2 != NULL) {
          proceed = (string(actpath1) == string(actpath2));
        }
      }
    }
  }
  
  str1 = prestr1;
  str2 = prestr2;
  
  cstr1 = (char *)str1.c_str();
  cstr2 = (char *)str2.c_str();
  
  if ((!proceed) || (proceed && string(basename(cstr1)) != string(basename(cstr2)))) {
    str1 = prestr1;
    str2 = prestr2;
    
    struct stat sb1;
    if (stat((char *)str1.c_str(), &sb1) == 0 &&
      S_ISREG(sb1.st_mode)) {
      double ret = 0;
      size_t sz1 = sb1.st_size;
      
      ifstream srce((char *)str1.c_str(), ios::binary);
      ret = (srce.tellg() >= 0);
      
      if (ret) {
        ofstream dest((char *)str2.c_str(), ios::binary);
        ret = (dest.tellp() >= 0);
      
        if (ret) {
          dest << srce.rdbuf();
          ret = (srce.tellg() - dest.tellp() == 0);
      
          struct stat sb2;
          if (stat((char *)str2.c_str(), &sb2) == 0 &&
            S_ISREG(sb2.st_mode)) {
            size_t sz2 = sb2.st_size;
            return ((ret == 1) ||
              (sz1 == 0 && sz2 == 0));
          }
        }
      }
    }
  }
  
  return 0;
}

double file_rename(char *oldname, char *newname) {
  string str1(oldname);
  string str2(newname);
  
  str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
  str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());
  
  int proceed = 0;
  
  string prestr1 = str1;
  string prestr2 = str2;
  
  char *cstr1 = (char *)str1.c_str();
  char *cstr2;
  
  string pardir1(dirname(cstr1));
  if (!pardir1.empty()) {
    while (*pardir1.rbegin() == '/') {
      pardir1.erase(pardir1.size() - 1);
    }
  }
  struct stat pexist1;
  if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
    S_ISDIR(pexist1.st_mode)) {
    char actpath1[PATH_MAX];
    char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
    if (ptr1 != NULL) {
      cstr2 = (char *)str2.c_str();
      string pardir2(dirname(cstr2));
      if (!pardir2.empty()) {
        while (*pardir2.rbegin() == '/')
        {
          pardir2.erase(pardir2.size() - 1);
        }
      }
      struct stat pexist2;
      if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
        S_ISDIR(pexist2.st_mode)) {
        char actpath2[PATH_MAX];
        char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
        if (ptr2 != NULL)
        {
          proceed = (string(actpath1) == string(actpath2));
        }
      }
    }
  }
  
  str1 = prestr1;
  str2 = prestr2;
  
  cstr1 = (char *)str1.c_str();
  cstr2 = (char *)str2.c_str();
  
  if ((!proceed) || (proceed && string(basename(cstr1)) != string(basename(cstr2)))) {
    str1 = prestr1;
    str2 = prestr2;
    
    struct stat sb1;
    struct stat sb2;
    if (stat((char *)str1.c_str(), &sb1) == 0 &&
      S_ISREG(sb1.st_mode) &&
      stat((char *)str2.c_str(), &sb2) != 0) {
      return (rename((char *)str1.c_str(), (char *)str2.c_str()) == 0);
    }
  }
  
  return 0;
}

double file_exists(char *fname) {
  string str(fname);
  
  struct stat sb;
  return (stat((char *)str.c_str(), &sb) == 0 &&
      S_ISREG(sb.st_mode));
}

double file_delete(char *fname) {
  string str(fname);
  
  struct stat sb;
  if (stat((char *)str.c_str(), &sb) == 0 &&
    S_ISREG(sb.st_mode)) {
    return (remove((char *)str.c_str()) == 0);
  }
  
  return 0;
}

double directory_create(char *dname) {
  string str(dname);
  
  if (!str.empty()) {
    while (*str.rbegin() == '/') {
      str.erase(str.size() - 1);
    }
  }
  
  struct stat sb;
  if (stat((char *)str.c_str(), &sb) != 0) {
    return (mkdir((char *)str.c_str(), 0777) == 0);
  }
  
  return 0;
}

double directory_copy(char *dname, char *newname) {
  string str1(dname);
  string str2(newname);
  
  str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
  str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());
  
  if (!str1.empty()) {
    while (*str1.rbegin() == '/') {
      str1.erase(str1.size() - 1);
    }
  }
  if (!str2.empty()) {
    while (*str2.rbegin() == '/') {
      str2.erase(str2.size() - 1);
    }
  }
  
  int proceed1 = 0;
  int proceed2 = 0;
  
  string prestr1 = str1;
  string prestr2 = str2;
  string poststr1 = str1;
  string poststr2 = str2;
  
  char *cstr1 = (char *)str1.c_str();
  char *cstr2;
  
  string pardir1(dirname(cstr1));
  if (!pardir1.empty()) {
    while (*pardir1.rbegin() == '/') {
      pardir1.erase(pardir1.size() - 1);
    }
  }
  
  struct stat pexist1;
  if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
    S_ISDIR(pexist1.st_mode)) {
    char actpath1[PATH_MAX];
    char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
    if (ptr1 != NULL) {
      cstr2 = (char *)str2.c_str();
      string pardir2(dirname(cstr2));
      if (!pardir2.empty()) {
        while (*pardir2.rbegin() == '/') {
          pardir2.erase(pardir2.size() - 1);
        }
      }
      struct stat pexist2;
      if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
        S_ISDIR(pexist2.st_mode)) {
        char actpath2[PATH_MAX];
        char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
        if (ptr2 != NULL)
        {
          char *cpoststr1 = (char *)poststr1.c_str();
          char *cpoststr2 = (char *)poststr2.c_str();
          
          string parbas1(string("/") + basename(cpoststr1));
          string parbas2(string("/") + basename(cpoststr2));
          
          proceed1 = (string(actpath1 + parbas1) != string(actpath2 + parbas2).substr(0, string(actpath1 + parbas1).length()));
          proceed2 = (string(actpath1) == string(actpath2));
        }
      }
    }
  }
  
  str1 = prestr1;
  str2 = prestr2;
  
  cstr1 = (char *)str1.c_str();
  cstr2 = (char *)str2.c_str();
  
  if ((proceed1 && !proceed2) || (proceed2 && string(basename(cstr1)) != string(basename(cstr2)))) {
    str1 = prestr1;
    str2 = prestr2;
    
    struct stat sb1;
    struct stat sb2;
    if (stat((char *)str1.c_str(), &sb1) == 0 &&
      S_ISDIR(sb1.st_mode) &&
      stat((char *)str2.c_str(), &sb2) != 0) {
      if (!directory_create((char *)str2.c_str()))
        return 0;
      
      DIR *dir;
      struct dirent *ent;
      if ((dir = opendir((char *)str1.c_str())) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
          if (string(ent->d_name) != ".") {
            if (string(ent->d_name) != "..") {
              string copy_sorc = str1 + "/" + ent->d_name;
              string copy_dest = str2 + "/" + ent->d_name;
              
              struct stat sb3;
              if (stat((char *)copy_sorc.c_str(), &sb3) == 0 &&
                S_ISDIR(sb3.st_mode)) {
                if (!directory_copy((char *)copy_sorc.c_str(), (char *)copy_dest.c_str()))
                  return 0;
              }
              
              struct stat sb4;
              if (stat((char *)copy_sorc.c_str(), &sb4) == 0 &&
                S_ISREG(sb4.st_mode)) {
                if (!file_copy((char *)copy_sorc.c_str(), (char *)copy_dest.c_str()))
                  return 0;
              }
            }
          }
        }
        
        closedir(dir);
      } else {
        return 0;
      }
      
      return 1;
    }
  }
  
  return 0;
}

double directory_rename(char *oldname, char *newname) {
  string str1(oldname);
  string str2(newname);
  
  str1.erase(unique(str1.begin(), str1.end(), dupslash()), str1.end());
  str2.erase(unique(str2.begin(), str2.end(), dupslash()), str2.end());
  
  if (!str1.empty()) {
    while (*str1.rbegin() == '/') {
      str1.erase(str1.size() - 1);
    }
  }
  if (!str2.empty()) {
    while (*str2.rbegin() == '/') {
      str2.erase(str2.size() - 1);
    }
  }
  
  int proceed1 = 0;
  int proceed2 = 0;
  
  string prestr1 = str1;
  string prestr2 = str2;
  string poststr1 = str1;
  string poststr2 = str2;
  
  char *cstr1 = (char *)str1.c_str();
  char *cstr2;
  
  string pardir1(dirname(cstr1));
  if (!pardir1.empty()) {
    while (*pardir1.rbegin() == '/') {
      pardir1.erase(pardir1.size() - 1);
    }
  }
  struct stat pexist1;
  if (stat((char *)pardir1.c_str(), &pexist1) == 0 &&
    S_ISDIR(pexist1.st_mode)) {
    char actpath1[PATH_MAX];
    char *ptr1 = realpath((char *)pardir1.c_str(), actpath1);
    if (ptr1 != NULL) {
      cstr2 = (char *)str2.c_str();
      string pardir2(dirname(cstr2));
      if (!pardir2.empty()) {
        while (*pardir2.rbegin() == '/') {
          pardir2.erase(pardir2.size() - 1);
        }
      }
      struct stat pexist2;
      if (stat((char *)pardir2.c_str(), &pexist2) == 0 &&
        S_ISDIR(pexist2.st_mode)) {
        char actpath2[PATH_MAX];
        char *ptr2 = realpath((char *)pardir2.c_str(), actpath2);
        if (ptr2 != NULL) {
          char *cpoststr1 = (char *)poststr1.c_str();
          char *cpoststr2 = (char *)poststr2.c_str();
          
          string parbas1(string("/") + basename(cpoststr1));
          string parbas2(string("/") + basename(cpoststr2));
          
          proceed1 = (string(actpath1 + parbas1) != string(actpath2 + parbas2).substr(0, string(actpath1 + parbas1).length()));
          proceed2 = (string(actpath1) == string(actpath2));
        }
      }
    }
  }
  
  str1 = prestr1;
  str2 = prestr2;
  
  cstr1 = (char *)str1.c_str();
  cstr2 = (char *)str2.c_str();
  
  if ((proceed1 && !proceed2) || (proceed2 && string(basename(cstr1)) != string(basename(cstr2)))) {
    str1 = prestr1;
    str2 = prestr2;
    
    struct stat sb1;
    struct stat sb2;
    if (stat((char *)str1.c_str(), &sb1) == 0 &&
      S_ISDIR(sb1.st_mode) &&
      stat((char *)str2.c_str(), &sb2) != 0) {
      return (rename((char *)str1.c_str(), (char *)str2.c_str()) == 0);
    }
  }
  
  return 0;
}

double directory_exists(char *dname) {
  string str(dname);
  
  if (!str.empty()) {
    while (*str.rbegin() == '/') {
      str.erase(str.size() - 1);
    }
  }
  
  struct stat sb;
  return (stat((char *)str.c_str(), &sb) == 0 &&
      S_ISDIR(sb.st_mode));
}

double directory_destroy(char *dname) {
  string str(dname);
  
  if (!str.empty()) {
    while (*str.rbegin() == '/') {
      str.erase(str.size() - 1);
    }
  }
  
  double ret = 0;
  
  struct stat sb;
  if (stat((char *)str.c_str(), &sb) == 0 &&
    S_ISDIR(sb.st_mode)) {
    ret = 1;
    FTS *ftsp = NULL;
    FTSENT *curr;
    
    char *files[] = {(char *)str.c_str(), NULL};
    ftsp = fts_open(files,  FTS_NOCHDIR | FTS_PHYSICAL | FTS_XDEV,  NULL);
    if (!ftsp) {
      ret = 0;
      goto finish;
    }
    
    while ((curr = fts_read(ftsp))) {
      switch (curr->fts_info) {
        case FTS_NS:
        case FTS_DNR:
        case FTS_ERR:
          break;
          
        case FTS_DC:
        case FTS_DOT:
        case FTS_NSOK:
          break;
          
        case FTS_D:
          break;
          
        case FTS_DP:
        case FTS_F:
        case FTS_SL:
        case FTS_SLNONE:
        case FTS_DEFAULT:
          if (remove(curr->fts_accpath) < 0) {
            ret = 0;
          }
          break;
      }
    }
    
  finish:
    if (ftsp) {
      fts_close(ftsp);
    }
  }
  
  return ret;
}

char *directory_contents(char *dname) {
  string str(dname);
  str.erase(unique(str.begin(), str.end(), dupslash()), str.end());
  
  if (!str.empty()) {
    while (*str.rbegin() == '/') {
      str.erase(str.size() - 1);
    }
  }
  
  if (string_replace_all(str, " ", "") == "")
    str = ".";
  
  if (str.back() != '/') 
    str += "/";

  struct stat pexist;
  if (stat((char *)str.c_str(), &pexist) == 0 &&
    S_ISDIR(pexist.st_mode)) {
    char actpath[PATH_MAX];
    char *ptr = realpath((char *)str.c_str(), actpath);
    if (ptr != NULL) {
      DIR *dir;
      struct dirent *ent;
      dir = opendir((char *)str.c_str());
      if (dir != NULL) {
        string result;
        while ((ent = readdir(dir))) {
          if (string(ent->d_name) != "." &&
            string(ent->d_name) != "..") {
            result += actpath;
            if (result.back() != '/')
              result += "/";
          
            result += ent->d_name;
            result += "\n";
          }
        }

        closedir(dir);
        if (result.back() != '\n')
          result.pop_back();

        static string fullres;
        fullres = result;
        return (char *)fullres.c_str();
      }
    }
  }
  
  return (char *)"";
}

char *environment_get_variable(char *name) {
  string str(name);
  char *env = getenv(str.c_str());
  
  if (env == NULL)
    return (char *)"";
  
  static string result1;
  result1 = env;
  
  struct stat sb;
  if (stat((char *)result1.c_str(), &sb) == 0 &&
    S_ISDIR(sb.st_mode)) {
    static string result2;
    static string result3;
    
    result2 = result1 + string("/");
    result3 = string_replace_all(result2, "//", "/");
    
    return (char*)result3.c_str();
  }
  
  return (char *)result1.c_str();
}

double environment_set_variable(char *name, char *value) {
  static string str1;
  static string str2;
  
  str1 = name;
  str2 = value;
  
  if (str2 == "")
    return (unsetenv(str1.c_str()) == 0);
  
  return (setenv(str1.c_str(), str2.c_str(), 1) == 0);
}

char *get_working_directory() {
  char cwd[PATH_MAX];
  if (getcwd(cwd, PATH_MAX) != NULL) {
    if (string(cwd) == "/") {
      if (generate_working_directory())
        return get_working_directory();
    }

    static string result1;
    static string result2;
    
    result1 = cwd + string("/");
    result2 = string_replace_all(result1, "//", "/");
    
    return (char *)result2.c_str();
  }
  
  return (char *)"";
}

double set_working_directory(char *dname) {
  string str(dname);
  
  if (!str.empty()) {
    while (*str.rbegin() == '/') {
      str.erase(str.size() - 1);
    }
  }
  
  struct stat sb;
  if (stat((char *)str.c_str(), &sb) == 0 &&
    S_ISDIR(sb.st_mode)) {
    return (chdir((char *)str.c_str()) == 0);
  }
  
  return 0;
}

char *get_program_directory() {
  char pathbuf[PATH_MAX];
  char real_executable[PATH_MAX];
  char *bundle_id;

  uint32_t bufsize = sizeof(pathbuf);
  if (_NSGetExecutablePath(pathbuf, &bufsize) == 0) {
    bundle_id = dirname(pathbuf);
    strcpy(real_executable, bundle_id);
    strcat(real_executable, "/");

    static string result1;
    static string result2;

    result1 = real_executable;
    result2 = string_replace_all(result1, "//", "/");

    return (char*)result2.c_str();
  }

  return (char *)"";
}

char *get_temp_directory() {
  char *env = getenv("TMPDIR");
  
  if (env == NULL)
    env = (char *)"/tmp";
  
  static string result1;
  static string result2;
  
  result1 = env + string("/");
  result2 = string_replace_all(result1, "//", "/");
  
  return (char*)result2.c_str();
}
