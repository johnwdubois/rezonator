/******************************************************************************

 MIT License

 Copyright � 2019 Samuel Venable

 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 SOFTWARE.

******************************************************************************/

#include "FileManager.h"
#include <windows.h>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <comdef.h>
#include <cwchar>
#include <algorithm>
#include <string>
#include <vector>
using namespace std;
using std::size_t;

typedef basic_string<wchar_t> tstring;

static tstring widen(string str) {
  const size_t wchar_count = str.size() + 1;

  vector<wchar_t> buf(wchar_count);

  return tstring{ buf.data(), (size_t)MultiByteToWideChar(CP_UTF8, 0, str.c_str(), -1, buf.data(), wchar_count) };
}

static string shorten(tstring str) {
  int nbytes = WideCharToMultiByte(CP_UTF8, 0, str.c_str(), (int)str.length(), NULL, 0, NULL, NULL);

  vector<char> buf((size_t)nbytes);

  return string{ buf.data(), (size_t)WideCharToMultiByte(CP_UTF8, 0, str.c_str(), (int)str.length(), buf.data(), nbytes, NULL, NULL) };
}

static string string_replace_all(string str, string substr, string newstr) {
  size_t pos = 0;
  const size_t sublen = substr.length(), newlen = newstr.length();

  while ((pos = str.find(substr, pos)) != string::npos) {
    str.replace(pos, sublen, newstr);
    pos += newlen;
  }

  return str;
}

double file_copy(char *fname, char *newname) {
  string str1 = fname;
  string str2 = newname;
  replace(str1.begin(), str1.end(), '/', '\\');
  replace(str2.begin(), str2.end(), '/', '\\');

  wchar_t rpath1[MAX_PATH];
  wchar_t rpath2[MAX_PATH];

  tstring wstr1 = widen(str1);
  tstring wstr2 = widen(str2);

  GetFullPathNameW(wstr1.c_str(), MAX_PATH, rpath1, NULL);
  GetFullPathNameW(wstr2.c_str(), MAX_PATH, rpath2, NULL);

  static string sstr1;
  static string sstr2;

  sstr1 = shorten(rpath1);
  sstr2 = shorten(rpath2);

  str1 = sstr1;
  str2 = sstr2;

  wstr1 = widen(str1);
  wstr2 = widen(str2);

  if (str1 != str2) {
    DWORD attr = GetFileAttributesW(wstr1.c_str());
    if (attr != INVALID_FILE_ATTRIBUTES &&
      (attr & ~FILE_ATTRIBUTE_DIRECTORY)) {
      return (CopyFileW(wstr1.c_str(), wstr2.c_str(), false) != 0);
    }
  }

  return 0;
}

double file_rename(char *oldname, char *newname) {
  string str1 = oldname;
  string str2 = newname;
  replace(str1.begin(), str1.end(), '/', '\\');
  replace(str2.begin(), str2.end(), '/', '\\');

  wchar_t rpath1[MAX_PATH];
  wchar_t rpath2[MAX_PATH];

  tstring wstr1 = widen(str1);
  tstring wstr2 = widen(str2);

  GetFullPathNameW(wstr1.c_str(), MAX_PATH, rpath1, NULL);
  GetFullPathNameW(wstr2.c_str(), MAX_PATH, rpath2, NULL);

  static string sstr1;
  static string sstr2;

  sstr1 = shorten(rpath1);
  sstr2 = shorten(rpath2);

  str1 = sstr1;
  str2 = sstr2;

  wstr1 = widen(str1);
  wstr2 = widen(str2);

  if (str1 != str2) {
    DWORD attr1 = GetFileAttributesW(wstr1.c_str());
    DWORD attr2 = GetFileAttributesW(wstr2.c_str());
    if (attr1 != INVALID_FILE_ATTRIBUTES &&
      (attr1 & ~FILE_ATTRIBUTE_DIRECTORY) &&
      attr2 == INVALID_FILE_ATTRIBUTES) {
      return (MoveFileW(wstr1.c_str(), wstr2.c_str()) != 0);
    }
  }

  return 0;
}

double file_exists(char *fname) {
  string str = fname;
  replace(str.begin(), str.end(), '/', '\\');

  tstring wstr = widen(str);
  DWORD attr = GetFileAttributesW(wstr.c_str());

  return (attr != INVALID_FILE_ATTRIBUTES &&
    (attr & ~FILE_ATTRIBUTE_DIRECTORY));
}

double file_delete(char *fname) {
  string str = fname;
  replace(str.begin(), str.end(), '/', '\\');

  tstring wstr = widen(str);
  DWORD attr = GetFileAttributesW(wstr.c_str());

  if (attr != INVALID_FILE_ATTRIBUTES &&
    (attr & ~FILE_ATTRIBUTE_DIRECTORY)) {
    return (DeleteFileW(wstr.c_str()) != 0);
  }

  return 0;
}

double directory_create(char *dname) {
  string str = dname;
  replace(str.begin(), str.end(), '/', '\\');

  if (!str.empty()) {
    while (*str.rbegin() == '\\') {
      str.erase(str.size() - 1);
    }
  }

  tstring wstr = widen(str);
  DWORD attr = GetFileAttributesW(wstr.c_str());

  if (attr == INVALID_FILE_ATTRIBUTES) {
    return (CreateDirectoryW(wstr.c_str(), NULL) != 0);
  }

  return 0;
}

double directory_copy(char *dname, char *newname) {
  string str1 = dname;
  string str2 = newname;
  replace(str1.begin(), str1.end(), '/', '\\');
  replace(str2.begin(), str2.end(), '/', '\\');

  wchar_t rpath1[MAX_PATH];
  wchar_t rpath2[MAX_PATH];

  tstring wstr1 = widen(str1);
  tstring wstr2 = widen(str2);

  GetFullPathNameW(wstr1.c_str(), MAX_PATH, rpath1, NULL);
  GetFullPathNameW(wstr2.c_str(), MAX_PATH, rpath2, NULL);

  static string sstr1;
  static string sstr2;

  sstr1 = shorten(rpath1);
  sstr2 = shorten(rpath2);

  str1 = sstr1;
  str2 = sstr2;

  if (!str1.empty()) {
    while (*str1.rbegin() == '\\') {
      str1.erase(str1.size() - 1);
    }
  }
  if (!str2.empty()) {
    while (*str2.rbegin() == '\\') {
      str2.erase(str2.size() - 1);
    }
  }

  int proceed = (str1 != str2.substr(0, str1.length()));

  wstr1 = widen(str1);
  wstr2 = widen(str2);

  if (proceed && str1 != str2) {
    DWORD attr1 = GetFileAttributesW(wstr1.c_str());
    DWORD attr2 = GetFileAttributesW(wstr2.c_str());
    if (attr1 != INVALID_FILE_ATTRIBUTES &&
      (attr1 & FILE_ATTRIBUTE_DIRECTORY) &&
      attr2 == INVALID_FILE_ATTRIBUTES) {
      SHFILEOPSTRUCTW fileop = { 0 };

      fileop.hwnd = NULL;
      fileop.wFunc = FO_COPY;
      fileop.pFrom = wstr1.c_str();
      fileop.pTo = wstr2.c_str();
      fileop.fFlags = FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT;

      return (SHFileOperationW(&fileop) == 0);
    }
  }

  return 0;
}

double directory_rename(char *oldname, char *newname) {
  string str1 = oldname;
  string str2 = newname;
  replace(str1.begin(), str1.end(), '/', '\\');
  replace(str2.begin(), str2.end(), '/', '\\');

  wchar_t rpath1[MAX_PATH];
  wchar_t rpath2[MAX_PATH];

  tstring wstr1 = widen(str1);
  tstring wstr2 = widen(str2);

  GetFullPathNameW(wstr1.c_str(), MAX_PATH, rpath1, NULL);
  GetFullPathNameW(wstr2.c_str(), MAX_PATH, rpath2, NULL);

  static string sstr1;
  static string sstr2;

  sstr1 = shorten(rpath1);
  sstr2 = shorten(rpath2);

  str1 = sstr1;
  str2 = sstr2;

  if (!str1.empty()) {
    while (*str1.rbegin() == '\\') {
      str1.erase(str1.size() - 1);
    }
  }
  if (!str2.empty()) {
    while (*str2.rbegin() == '\\') {
      str2.erase(str2.size() - 1);
    }
  }

  int proceed = (str1 != str2.substr(0, str1.length()));

  wstr1 = widen(str1);
  wstr2 = widen(str2);

  if (proceed && str1 != str2) {
    DWORD attr1 = GetFileAttributesW(wstr1.c_str());
    DWORD attr2 = GetFileAttributesW(wstr2.c_str());

    if (attr1 != INVALID_FILE_ATTRIBUTES &&
      (attr1 & FILE_ATTRIBUTE_DIRECTORY) &&
      attr2 == INVALID_FILE_ATTRIBUTES) {
      return (MoveFileW(wstr1.c_str(), wstr2.c_str()) != 0);
    }
  }

  return 0;
}

double directory_exists(char *dname) {
  string str = dname;
  replace(str.begin(), str.end(), '/', '\\');

  if (!str.empty()) {
    while (*str.rbegin() == '\\') {
      str.erase(str.size() - 1);
    }
  }

  tstring wstr = widen(str);
  DWORD attr = GetFileAttributesW(wstr.c_str());

  return (attr != INVALID_FILE_ATTRIBUTES &&
    (attr & FILE_ATTRIBUTE_DIRECTORY));
}

double directory_destroy(char *dname) {
  string str = dname;
  replace(str.begin(), str.end(), '/', '\\');

  wchar_t rpath[MAX_PATH];
  tstring wstr = widen(str);
  GetFullPathNameW(wstr.c_str(), MAX_PATH, rpath, NULL);

  static string sstr;
  sstr = shorten(rpath);
  str = sstr;

  if (!str.empty()) {
    while (*str.rbegin() == '\\') {
      str.erase(str.size() - 1);
    }
  }

  wstr = widen(str);
  DWORD attr = GetFileAttributesW(wstr.c_str());

  if (attr != INVALID_FILE_ATTRIBUTES &&
    (attr & FILE_ATTRIBUTE_DIRECTORY)) {
    SHFILEOPSTRUCTW fileop = { 0 };

    fileop.hwnd = NULL;
    fileop.wFunc = FO_DELETE;
    fileop.pFrom = wstr.c_str();
    fileop.fFlags = FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT;

    return (SHFileOperationW(&fileop) == 0);
  }

  return 0;
}

char *directory_contents(char *dname) {
  string str = dname;
  replace(str.begin(), str.end(), '/', '\\');
  if (string_replace_all(str, " ", "") == "")
    str = ".";

  wchar_t rpath[MAX_PATH];
  tstring wstr = widen(str);
  GetFullPathNameW(wstr.c_str(), MAX_PATH, rpath, NULL);

  static string sstr;
  sstr = shorten(rpath);
  str = sstr + "\\*";

  if (!str.empty()) {
	  while (*str.rbegin() == '\\') {
		  str.erase(str.size() - 1);
	  }
  }

  wstr = widen(str);

  WIN32_FIND_DATAW data;
  HANDLE hFind = FindFirstFileW(wstr.c_str(), &data);
  tstring wstr_result;

  if (hFind != INVALID_HANDLE_VALUE) {
    do {
      if ((data.dwFileAttributes != INVALID_FILE_ATTRIBUTES &&
        data.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) ||
        (data.dwFileAttributes != INVALID_FILE_ATTRIBUTES &&
        data.dwFileAttributes & ~FILE_ATTRIBUTE_DIRECTORY)) {
        if (shorten(data.cFileName) != "." && shorten(data.cFileName) != "..") {
		  wstr_result += rpath;
          if (rpath[wcslen(rpath) - 1] != '\\')
            wstr_result += L"\\";

          wstr_result += data.cFileName;
	      wstr_result += L"\n";
        }
	  }
    } while (FindNextFileW(hFind, &data));
      FindClose(hFind);
  }

  if (wstr_result.back() == '\n')
    wstr_result.pop_back();

  static string result;
  result = shorten(wstr_result);
  return (char *)result.c_str();
}

char *environment_get_variable(char *name) {
  string str = name;
  tstring wstr = widen(str);

  static wchar_t result[65535];
  if (GetEnvironmentVariableW(wstr.c_str(), result, 65535)) {
    DWORD attr = GetFileAttributesW(result);

    static string str_result1;
    str_result1 = shorten(result);

    if (attr != INVALID_FILE_ATTRIBUTES &&
      (attr & FILE_ATTRIBUTE_DIRECTORY)) {
      static string str_result2;
      static string str_result3;

      str_result2 = str_result1 + "\\";
      str_result3 = string_replace_all(str_result2, "\\\\", "\\");

      return (char *)str_result3.c_str();
    }

    return (char *)str_result1.c_str();
  }

  return (char *)"";
}

double environment_set_variable(char *name, char *value) {
  string str1 = name;
  tstring wstr1 = widen(str1);

  string str2 = value;
  tstring wstr2 = widen(str2);

  if (str2 == "")
    return (SetEnvironmentVariableW(wstr1.c_str(), NULL) != 0);

  return (SetEnvironmentVariableW(wstr1.c_str(), wstr2.c_str()) != 0);
}

char *get_working_directory() {
  wchar_t result[MAX_PATH];
  GetCurrentDirectoryW(MAX_PATH, result);

  static string str_result1;
  static string str_result2;
  static string str_result3;

  str_result1 = shorten(result);
  str_result2 = str_result1 + "\\";
  str_result3 = string_replace_all(str_result2, "\\\\", "\\");

  return (char *)str_result3.c_str();
}

double set_working_directory(char *dname) {
  string str = dname;
  replace(str.begin(), str.end(), '/', '\\');

  if (!str.empty()) {
    while (*str.rbegin() == '\\') {
      str.erase(str.size() - 1);
    }
  }

  tstring wstr = widen(str);
  DWORD attr = GetFileAttributesW(wstr.c_str());

  if (attr != INVALID_FILE_ATTRIBUTES &&
    (attr & FILE_ATTRIBUTE_DIRECTORY)) {
    return (SetCurrentDirectoryW(wstr.c_str()) != 0);
  }

  return 0;
}

char *get_program_directory() {
  wchar_t result[MAX_PATH];
  GetModuleFileNameW(NULL, result, MAX_PATH);

  static string::size_type pos;
  pos = shorten(result).find_last_of("\\");

  if (pos != string::npos) {
    static string str_result1;
    static string str_result2;
    static string str_result3;

    str_result1 = shorten(result);
    str_result2 = str_result1.substr(0, pos) + "\\";
    str_result3 = string_replace_all(str_result2, "\\\\", "\\");

    return (char *)str_result3.c_str();
  }

  return (char *)"";
}

char *get_temp_directory() {
  wchar_t result[MAX_PATH];
  GetTempPathW(MAX_PATH, result);

  static string str_result1;
  static string str_result2;
  static string str_result3;

  str_result1 = shorten(result);
  str_result2 = str_result1 + "\\";
  str_result3 = string_replace_all(str_result2, "\\\\", "\\");

  return (char *)str_result3.c_str();
}
